<?php
 if(isset($_GET["submit"]))
 {
    if(isset($_GET["no1"]) && isset($_GET["no2"])){
        $no1 = $_GET["no1"];
        $no2 = $_GET["no2"];
        $res = $no1 + $no2;
    }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <div class="container">
        <form action="#" method="get">
                <label for="fname" >First : </label>
                <input type="number" name="no1"><hr></hr>
                <label for="fid" >Second :</label>
                <input type="number" name="no2"><hr></hr>
                <button type="submit" name="submit">submit</button><hr></hr>
                <label for="pass">Answer :</label>
                <input type="number" name="res" value="<?php echo $res; ?>"><hr></hr>
        </form>
    </div>
</body>
</html>